import math
import sys
import os
import csv
import numpy as numpy

#declare your own function(s)
def func1():
    print("Test")

if __name__ == "__main__":
    func1()
